<?
header("Location: http://www.csszengarden.com/?cssfile=036/036.css");
?>
