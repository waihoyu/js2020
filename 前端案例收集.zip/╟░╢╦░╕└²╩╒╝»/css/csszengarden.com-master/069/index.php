<?
header("Location: http://www.csszengarden.com/?cssfile=069/069.css");
?>
