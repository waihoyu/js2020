<?
header("Location: http://www.csszengarden.com/?cssfile=009/009.css");
?>
