<?
header("Location: http://www.csszengarden.com/?cssfile=096/096.css");
?>
