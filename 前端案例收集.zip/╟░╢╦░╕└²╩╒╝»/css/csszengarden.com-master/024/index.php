<?
header("Location: http://www.csszengarden.com/?cssfile=024/024.css");
?>
