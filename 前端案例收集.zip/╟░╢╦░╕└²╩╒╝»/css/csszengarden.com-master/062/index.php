<?
header("Location: http://www.csszengarden.com/?cssfile=062/062.css");
?>
