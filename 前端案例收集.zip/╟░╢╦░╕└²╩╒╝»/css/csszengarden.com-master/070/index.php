<?
header("Location: http://www.csszengarden.com/?cssfile=070/070.css");
?>
