<?
header("Location: http://www.csszengarden.com/?cssfile=019/019.css");
?>
