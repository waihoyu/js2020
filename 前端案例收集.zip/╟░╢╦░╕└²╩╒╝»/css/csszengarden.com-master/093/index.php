<?
header("Location: http://www.csszengarden.com/?cssfile=093/093.css");
?>
