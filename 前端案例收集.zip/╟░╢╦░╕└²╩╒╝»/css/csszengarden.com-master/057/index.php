<?
header("Location: http://www.csszengarden.com/?cssfile=057/057.css");
?>
