<?
header("Location: http://www.csszengarden.com/?cssfile=029/029.css");
?>
